import React, { useState, useEffect } from 'react';
import 'bootstrap/dist/css/bootstrap.min.css';
import CarreraDetalle from '../components/CarreraDetalle';
import { Link } from 'react-router-dom';  // Agrega esta línea




const CarreraList = () => {
  const [carreras, setCarreras] = useState([]);

  useEffect(() => {
    fetch('http://localhost:3000/GetCarreras')
      .then(response => response.json())
      .then(data => setCarreras(data))
      .catch(error => console.error('Error:', error));
      
  }, []);
 

  return (
    <div className="card-list">
      {carreras.map(Carrera => (
        <div className="card" key={Carrera.IdCarrera}>
          <img className="card-img-top" src={Carrera.Imagen} />
          <div className="card-body">
            <h5 className="card-title">{Carrera.Nombre}</h5>
            <p className="card-text">{Carrera.Descripcion}</p>
            <Link to={`/DetalleCarrera/${Carrera.IdCarrera}`} className="btn btn-primary">
            Más información
          </Link>
           
          </div>

          <br></br>
        </div>
      ))}
    </div>
  );
};

export default CarreraList;

