import React from "react";
import UniversidadList from "../Models/UniversidadList";
import BasicExample from "./NavBar";

export const SegundoComponente = () => {
  const handleFiltrarClick = () => {
    // Lógica de filtrado aquí
    console.log("Filtrar haciendo clic en el botón");
  };

  return (
    <div className="carrera">
      <BasicExample />
      <h1>UNI CHOICE</h1>
      <br></br>
      <h2>ENCONTRA TU UNIVERSIDAD IDEAL</h2>
      <div id="gradient"></div>
      <form className="searchbox" action="">
        <input type="search" placeholder="Search" />
        <button type="submit" value="search">
          &nbsp;
        </button>
      </form>

      {/* Botón de filtro */}
      <button className="filtro-btn" onClick={handleFiltrarClick}>
        Filtrar
      </button>

      <div>
        {/* Resto del contenido... */}
      </div>

      <UniversidadList />
    </div>
  );
};