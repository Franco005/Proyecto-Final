import React, { useState } from 'react';
import 'bootstrap/dist/css/bootstrap.min.css';

const Buscador = () => {
  const [busqueda, setBusqueda] = useState('');
  const [resultados, setResultados] = useState([]);

  const handleInputChange = (event) => {
    setBusqueda(event.target.value);
  };

  const handleBuscar = async () => {
    try {
      console.log(response);
      const response = await fetch(`http://localhost:3000/Buscar`, {
        method: 'POST',
        headers: {
          'Content-Type': 'application/json',
        },
        body: JSON.stringify({ busqueda }),
        
      });
      if (response.ok) {
        const data = await response.json();
        setResultados(data);
      } else {
        console.error('Error en la solicitud');
      }
    } catch (error) {
      console.error('Error de red:', error);
    }
  };

  return (
    <div>
      <form className="searchbox" action="">
        <input
          type="search"
          placeholder="Buscar carreras o instituciones"
          onChange={handleInputChange}
        />
        <button type="button" onClick={handleBuscar}>
          Buscar
        </button>
      </form>

      {resultados.carreras && (
        <div>
          <h2>Carreras encontradas:</h2>
          <div className="card-list">
            {resultados.carreras.map((carrera) => (
              <div className="card" key={carrera.IdCarrera}>
                <div className="card-body">
                  <h5 className="card-title">{carrera.Nombre}</h5>
                  <p className="card-text">{carrera.Descripcion}</p>
                  {/* Agrega más campos según sea necesario */}
                </div>
              </div>
            ))}
          </div>
        </div>
      )}

      {resultados.instituciones && (
        <div>
          <h2>Instituciones encontradas:</h2>
          <div className="card-list">
            {resultados.instituciones.map((institucion) => (
              <div className="card" key={institucion.IdInstitucion}>
                <div className="card-body">
                  <h5 className="card-title">{institucion.Nombre}</h5>
                  <p className="card-text">{institucion.Descripcion}</p>
                  {/* Agrega más campos según sea necesario */}
                </div>
              </div>
            ))}
          </div>
        </div>
      )}
    </div>
  );
};

export default Buscador;
