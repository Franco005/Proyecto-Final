import React, { useState, useEffect } from 'react';
import { useParams } from 'react-router-dom';

const DetallesUniversidad = () => {
  const { id } = useParams();
  const [universidad, setUniversidad] = useState({});
  const [carreras, setCarreras] = useState([]);

  useEffect(() => {
    fetch(`http://localhost:3000/DetalleInstitucion/${id}`)
      .then(response => {
        if (!response.ok) {
          throw new Error('No se pudo obtener la información de la universidad.');
        }
        return response.json();
      })
      .then(data => {
        if (data.length === 1) {
          // Si hay un objeto en el array, actualiza el estado de la universidad
          setUniversidad(data[0]);
        } else {
          // Manejar el caso en el que no se encontró la universidad
          console.error('No se encontró la universidad.');
        }
      })
      .catch(error => console.error('Error:', error));

    fetch(`http://localhost:3000/Institucion/${id}`)
      .then(response => {
        if (!response.ok) {
          throw new Error('No se pudo obtener la información de las carreras.');
        }
        return response.json();
      })
      .then(data => setCarreras(data))
      .catch(error => console.error('Error:', error));
  }, [id]);

  return (
    <div className="detalles-universidad">
      <u> <h1>Detalles de la Universidad</h1> </u>
      <h2>{universidad.Nombre}</h2>
      <div>
        <p>{universidad.Descripcion || 'Descripción no disponible'}</p>
        <p>Provincia: {universidad.Provincia || 'Provincia no disponible'}</p>
        <p>Ciudad: {universidad.Ciudad || 'Ciudad no disponible'}</p>
    
      </div>
      {carreras.length === 0 ? (
        <div>No hay información de carreras disponible para esta universidad.</div>
      ) : (
        <div>
          <u> <h1>Carreras</h1> </u>
          {carreras.map(carrera => (
            <div key={carrera.IdCarrera}>
              <h4>{carrera.Nombre}</h4>
              <p>{carrera.Descripcion}</p>
              <p>Plan de Estudio: {carrera.PlanEstudio}</p>
              <p>Cuota: {carrera.Cuota}</p>
            </div>
          ))}
        </div>
      )}
    </div>
  );
};

export default DetallesUniversidad;
