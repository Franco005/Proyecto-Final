import React, { useState } from 'react';
import { Link } from 'react-router-dom';
import CarreraList from '../Models/CarreraList';
import BasicExample from './NavBar';

export const PrimerComponente = () => {
  const [busqueda, setBusqueda] = useState('');
  const [resultados, setResultados] = useState({ carreras: [], instituciones: [] });

  const handleBuscar = async () => {
    try {
      const response = await fetch(`http://localhost:3000/Buscar`, {
        method: 'POST',
        headers: {
          'Content-Type': 'application/json',
        },
        body: JSON.stringify({ busqueda }),
      });

      console.log(busqueda);
      if (response.ok) {
        const data = await response.json();
        console.log('Resultados de búsqueda:', data);
        setResultados(data);
      } else {
        console.error('Error en la solicitud');
      }
    } catch (error) {
      console.error('Error de red:', error);
    }
  };

  return (
    <div className="carrera">
      <BasicExample />
      <h1>UNI CHOICE</h1>
      <br></br>
      <h2>ENCONTRA TU CARRERA IDEAL</h2>

      <div id="gradient"></div>

      <form
        className="searchbox"
        onSubmit={(e) => {
          e.preventDefault();
          handleBuscar();
        }}
      >
        <input
          type="search"
          placeholder="Search"
          value={busqueda}
          onChange={(e) => setBusqueda(e.target.value)}
        />
        <button type="submit" value="search">
          &nbsp;
        </button>
      </form>

      <div className="result-list">
        {resultados.carreras.map((carrera) => (
          <div className="result-card" key={carrera.IdCarrera}>
            <img className="result-img" src={carrera.Imagen} alt={carrera.Nombre} />
            <div className="result-details">
              <h5 className="result-title">{carrera.Nombre}</h5>
              <p className="result-description">{carrera.Descripcion}</p>
              <Link to={`/DetalleCarrera/${carrera.IdCarrera}`} className="btn btn-primary"> Más información</Link>
            </div>
          </div>
        ))}
        
        {resultados.instituciones.map((institucion) => (
          <div className="result-card" key={institucion.IdInstitucion}>
            <img className="result-img" src={institucion.Imagen} alt={institucion.Nombre} />
            <div className="result-details">
              <h5 className="result-title">{institucion.Nombre}</h5>
              <Link to={`/DetalleCarrera/${institucion.IdInstitucion}`} className="btn btn-primary"> Más información</Link>
            </div>
          </div>
        ))}
      </div>

      {<CarreraList />}
    </div>
  );
};
