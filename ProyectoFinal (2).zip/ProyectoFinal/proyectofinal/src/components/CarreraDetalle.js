import React, { useState, useEffect } from 'react';
import { useParams } from 'react-router-dom';  // Importa useParams
import 'bootstrap/dist/css/bootstrap.min.css';

const CarreraDetalle = () => {
  const { id } = useParams(); // Asegúrate de importar `useParams` de 'react-router-dom'
  const [carrera, setCarrera] = useState({});

  useEffect(() => {
    fetch(`http://localhost:3000/DetalleCarrera/${id}`)
      .then(response => response.json())
      .then(data => setCarrera(data))
      .catch(error => console.error('Error:', error));
  }, [id]);

  return (
    <div>
      <h1>{carrera.Nombre}</h1>
      <p>Plan de Estudio: {carrera.PlanEstudio}</p>
      <p>Cuota: {carrera.Cuota}</p>
      <p>Modalidad: {carrera.ModalidadDescripcion}</p>
    </div>
  );
};

export default CarreraDetalle;
