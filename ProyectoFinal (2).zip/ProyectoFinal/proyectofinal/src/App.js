import './App.css';

import { SegundoComponente } from './components/SegundoComponente';
import React from 'react';
import LoginRegister from './Models/loginResgister';
import DetallesUniversidad from './components/DetallesUniversidad';
import CarreraDetalle from './components/CarreraDetalle';
import { BrowserRouter, Route, Routes, Navigate } from 'react-router-dom'; // Asegúrate de importar Navigate
import { PrimerComponente } from './components/PrimerComponente';


function App() {
  return (
    
    <div className="App">
      
      <BrowserRouter>
        <Routes>
          <Route path="/" element={<LoginRegister />} />
          <Route path="/segundo-componente" element={<SegundoComponente />} />
          <Route path="/Institucion/:id" element={<DetallesUniversidad />} />
          <Route path="/DetalleCarrera/:id" element={<CarreraDetalle />} />
          <Route path="/carreras" element={<PrimerComponente />} /> 

        </Routes>
      </BrowserRouter>
    </div>
      
  );
}

export default App;