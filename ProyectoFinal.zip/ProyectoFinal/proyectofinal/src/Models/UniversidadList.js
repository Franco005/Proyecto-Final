import React, { useState, useEffect } from 'react';

const UniversidadList = () => {
  const [instituciones, setInstituciones] = useState([]);

  useEffect(() => {
    fetch('http://localhost:3000/Institucion')
      .then(response => response.json())
      .then(data => setInstituciones(data))
      .catch(error => console.error('Error:', error));
      
      console.log(instituciones)
  }, []);

  return (
    <div className="top">
      {instituciones.map(Institucion => (
        <figure key={Institucion.IdInstitucion}>
          <img src={Institucion.Imagen} alt="" className="cardimage" />
          <figcaption>{Institucion.Nombre}</figcaption>
        </figure>
      ))}
    </div>
  );
};

export default UniversidadList;

