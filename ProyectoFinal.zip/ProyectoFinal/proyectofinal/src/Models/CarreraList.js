import React, { useState, useEffect } from 'react';
import 'bootstrap/dist/css/bootstrap.min.css';


const CarreraList = () => {
  const [carreras, setCarreras] = useState([]);

  useEffect(() => {
    fetch('http://localhost:3000/GetCarreras')
      .then(response => response.json())
      .then(data => setCarreras(data))
      .catch(error => console.error('Error:', error));
  }, []);

  return (
    <div className="card-list">
      {carreras.map(Carrera => (
        <div className="card" key={Carrera.IdCarrera}>
          <img className="card-img-top" src={Carrera.Imagen} alt={Carrera.Nombre} />
          <div className="card-body">
            <h5 className="card-title">{Carrera.Nombre}</h5>
            <p className="card-text">{Carrera.Descripcion}</p>
            <p className="card-text">Plan de Estudio: {Carrera.PlanEstudio}</p>
            <p className="card-text">Cuota: {Carrera.Cuota}</p>
            <p className="card-text">Modalidad: {Carrera.Modalidad}</p>
            <a href="..." className="btn btn-primary">Más información</a>
          </div>
        </div>
      ))}
    </div>
  );
};

export default CarreraList;

