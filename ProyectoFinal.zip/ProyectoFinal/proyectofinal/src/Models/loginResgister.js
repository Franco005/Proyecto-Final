import React, { useState } from 'react';
import { useNavigate } from 'react-router-dom';

const LoginForm = () => {
  const navigate = useNavigate();
  const [activeForm, setActiveForm] = useState('login');
  const [loginEmail, setLoginEmail] = useState('');
  const [loginPassword, setLoginPassword] = useState('');
  const [error, setError] = useState('');

  const handleFormSwitch = (formType) => {
    setActiveForm(formType);
  };

  const handleLoginSubmit = async (e) => {
    e.preventDefault();

    try {
      const response = await fetch('http://localhost:3000/login', {
        method: 'POST',
        headers: {
          'Content-Type': 'application/json',
        },
        body: JSON.stringify({
          Usuario: loginEmail,
          Contraseña: loginPassword,
        }),
      });

      if (response.ok) {
        // Login exitoso, redirige a la página principal o a donde desees.
        console.log('Login successful');
        navigate('/segundo-componente');
      } else {
        const data = await response.json();
        if (response.status === 401) {
          // Usuario no encontrado o contraseña incorrecta
          if (data.message === 'Credenciales inválidas: Usuario no encontrado') {
            setError('El usuario no existe, regístrate');
          } else if (data.message === 'Credenciales inválidas: Contraseña incorrecta') {
            setError('La contraseña es incorrecta');
          }
        } else {
          console.log('Otro error de login:', data.message);
        }
      }
    } catch (error) {
      console.error('Error:', error);
    }
  };
  return (
    <section className="forms-section">
      <h1 className="section-title">Bienvenido a UniChoice!</h1>
      <div className="forms">
        <div className={`form-wrapper ${activeForm === 'login' ? 'is-active' : ''}`}>
          <button type="button" className="switcher switcher-login" onClick={() => handleFormSwitch('login')}>
            Login
            <span className="underline"></span>
          </button>
          <form className={`form form-login ${activeForm === 'login' ? 'is-active' : ''}`} onSubmit={handleLoginSubmit}>
            <fieldset>
              <legend></legend>
              <div className="input-block">
                <label htmlFor="login-email">E-mail</label>
                <input
                  id="login-email"
                  type="email"
                  required
                  value={loginEmail}
                  onChange={(e) => setLoginEmail(e.target.value)}
                />
              </div>
              <div className="input-block">
                <label htmlFor="login-password">Password</label>
                <input
                  id="login-password"
                  type="password"
                  required
                  value={loginPassword}
                  onChange={(e) => setLoginPassword(e.target.value)}
                />
              </div>
            </fieldset>
            <button type="submit" className="btn-login">Login</button>
          </form>
        </div>
        <div className={`form-wrapper ${activeForm === 'signup' ? 'is-active' : ''}`}>
          <button type="button" className="switcher switcher-signup" onClick={() => handleFormSwitch('signup')}>
            Registrarse
            <span className="underline"></span>
          </button>
          <form className={`form form-signup ${activeForm === 'signup' ? 'is-active' : ''}`} onSubmit={handleSignupSubmit}>
            <fieldset>
              <legend>Please, enter your information for sign up.</legend>
              <div className="input-block">
                <label htmlFor="signup-nombre">Nombre</label>
                <input
                  id="signup-nombre"
                  type="text"
                  required
                  value={signupNombre}
                  onChange={(e) => setSignupNombre(e.target.value)}
                />
              </div>
              <div className="input-block">
                <label htmlFor="signup-apellido">Apellido</label>
                <input
                  id="signup-apellido"
                  type="text"
                  required
                  value={signupApellido}
                  onChange={(e) => setSignupApellido(e.target.value)}
                />
              </div>
              <div className="input-block">
                <label htmlFor="signup-email">E-mail</label>
                <input
                  id="signup-email"
                  type="email"
                  required
                  value={signupEmail}
                  onChange={(e) => setSignupEmail(e.target.value)}
                />
              </div>
              <div className="input-block">
                <label htmlFor="signup-celular">Celular</label>
                <input
                  id="signup-celular"
                  type="text"
                  required
                  value={signupCelular}
                  onChange={(e) => setSignupCelular(e.target.value)}
                />
              </div>
              <div className="input-block">
                <label htmlFor="signup-provincia">Provincia</label>
                <input
                  id="signup-provincia"
                  type="text"
                  required
                  value={signupProvincia}
                  onChange={(e) => setSignupProvincia(e.target.value)}
                />
              </div>
              <div className="input-block">
                <label htmlFor="signup-password">Password</label>
                <input
                  id="signup-password"
                  type="password"
                  required
                  value={signupPassword}
                  onChange={(e) => setSignupPassword(e.target.value)}
                />
              </div>
            </fieldset>
            <button type="submit" className="btn-signup">Continue</button>
          </form>
        </div>
      </div>
    </section>
  );
};

export default LoginForm;
