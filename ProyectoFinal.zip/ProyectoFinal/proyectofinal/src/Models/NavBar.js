/*import React from 'react';
import { Link } from 'react-router-dom';

const Navbar = ({ usuarioLogueado, onEditarPerfilClick }) => {
  return (
    <nav className="navbar">
      <div className="navbar-brand">
        <Link to="/segundo-componente">Home</Link>
      </div>
      <div className="navbar-user">
        {usuarioLogueado ? (
          <div>
            <span>Bienvenido, {usuarioLogueado}</span>
            <button onClick={onEditarPerfilClick}>Editar Perfil</button>
          </div>
        ) : (
          <Link to="/">Cerrar Sesión</Link>
        )}
      </div>
    </nav>
  );
};

export default Navbar;*/
