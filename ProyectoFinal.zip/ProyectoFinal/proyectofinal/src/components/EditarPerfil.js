import React from "react"
export const PrimerComponente = () =>{
    return(
        
    <p></p>
    )
}