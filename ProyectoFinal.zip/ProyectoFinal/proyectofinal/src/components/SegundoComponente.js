import React from "react";
import UniversidadList from "../Models/UniversidadList";
export const SegundoComponente = () =>{
    return(
        <div className="carrera">
            <h1>UNI CHOICE</h1>
            <br></br>
            <h2>ENCONTRA TU UNIVERSIDAD IDEAL</h2>
            <div id="gradient"></div>
         <form class="searchbox" action="">
            <input type="search" placeholder="Search" />
            <button type="submit" value="search">&nbsp;</button>
        </form>
        
            <div>
    
  </div>
  <UniversidadList />
        </div>
        
    )
    }

    