import './App.css';

import { SegundoComponente } from './components/SegundoComponente';
import React from 'react';
import LoginRegister from './Models/loginResgister';
import UniversidadList from './Models/UniversidadList'; 
import CarreraList from './Models/CarreraList';

import { BrowserRouter, Route, Routes, Navigate } from 'react-router-dom'; // Asegúrate de importar Navigate

function App() {
  return (
    <div className="App">
      <BrowserRouter>
        <Routes>
          <Route path="/" element={<LoginRegister />} />
          <Route path="/segundo-componente" element={<SegundoComponente />} />
        </Routes>
      </BrowserRouter>
    </div>
      
  );
}

export default App;